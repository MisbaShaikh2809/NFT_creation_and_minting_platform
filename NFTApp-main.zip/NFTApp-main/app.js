const express = require('express')
const bodyParser = require('body-parser');
const ejs = require('ejs');
const { Configuration, OpenAIApi } = require("openai");
const PORT = process.env.PORT || 3000;

//Original Key
//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
const configuration = new Configuration({
  apiKey: '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',
});

// initialize app
app = express();

const openai = new OpenAIApi(configuration);
app.use(bodyParser.urlencoded({extended: true}));
app.set('view engine', 'ejs');
app.use(express.static("public"));

// home
app.get('/', function(req, res){
    res.render('home');
});

//create page
var imageSource = "images/sample-nft.png";
var loading = "";

app.get('/create', function(req, res){
    res.render('create', {imageSource: imageSource, loading: loading});
})

//mint
app.get('/mint', function(req, res){
    res.render('mint');
});

// request 
app.post('/openai/generate', async function(req, res){
    const imageDescription = req.body.imageDescription;
    let response;

    //show spinner here  
    imageSource="";
    loading="spinner show";

    try{
        response = await openai.createImage({
            prompt: imageDescription,
            n: 1,
            size: "512x512",
        });
    
        const imageUrl = response.data.data[0].url;

        //show image here
        imageSource = imageUrl;
        loading = "";
    
        // res.status(200).json({
        //     success: true,
        //     data: imageUrl
        // });

    
    }
    catch(err){
        imageSource="";
        loading="";

        //hide spinner here

        // res.status(400).json({
        //     success: false,
        //     data: err.message
        // });
    }

    res.redirect("/create");
});

app.listen(PORT, function(){
    console.log('listening on port '+PORT);
})